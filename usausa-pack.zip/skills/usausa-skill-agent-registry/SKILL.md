---
name: usausa-skill-agent-registry
description: Claude CodeのSkill・Agentを棚卸しし、管理スプレッドシート・Notion DB・Googleドキュメントを一括で作成/更新する時短Skill。「スキル管理台帳」「棚卸し」「エージェント一覧」「スキル作ったので台帳に追加」で使う。
---

# usausa-skill-agent-registry

作ったSkill・使うAgentを1回の棚卸しから、3つの台帳（Googleスプレッドシート／Notion DB／Googleドキュメント）へ一括反映する。正本はスプレッドシート。

## 1. 使うタイミング
1. 「スキル・エージェントの管理台帳を作って」「棚卸しして」と言われたとき
2. 新しいSkill/Agentを作った直後に「台帳に追加」と言われたとき
3. 月次の見直し（状態が「要登録確認」の行の再確認）

## 2. 既定値で進める
全Skill・全Agentが対象／確認日は当日／Notion DBは非公開（ワークスペース直下）で作成。

## 3. 手順
### Step 1 棚卸し
1. `.claude/skills/`、`~/.claude/skills/` の各 SKILL.md の frontmatter（name・description）
2. `.claude/agents/`、`~/.claude/agents/` の定義ファイル
3. アカウントSkill（同期済み一覧）
4. メモリ（/areas/ 内のSkill制作記録：最終更新日・関連Skill）
5. 組み込みエージェント（Explore／Plan／general-purpose／claude-code-guide／statusline-setup）
- 見つからないものは推測で埋めず「—」または「description参照」

### Step 2 台帳データ
列：ID／種別／名前／カテゴリ／区分／用途／主なトリガー／関連／形態・保管先／状態／最終更新(メモリ記録)／次のアクション／確認日
- ID：Skill=SK-001〜、Agent=AG-xxx（連番を引き継ぐ）
- 状態：稼働中／要登録確認／提案中／統合候補／廃止
- CSV(UTF-8、カンマ含むセルは "" で囲む)とJSONを作業フォルダに保存

### Step 3 重複・整理の検出
1. 用途が近いものを「統合候補」に
2. 関連列の相互参照を確認し、親Skillを決める
3. 「要登録確認」「統合候補」の件数を集計

### Step 4 3つの台帳を作る
1. Googleスプレッドシート：Drive create_file に CSV を contentMimeType text/csv で渡す
2. Notion DB：create-database（状態・種別・カテゴリ・区分はセレクト、確認日は日付）→ create-pages で全行。プロパティ名 ID は `userDefined:ID`、日付は `date:確認日:start` と `date:確認日:is_datetime`=0。最初は非公開で作り、移動先を聞く
3. Googleドキュメント：HTMLを text/html で create_file。構成は 1.目的 2.台帳の置き場所 3.現在の状況 4.カテゴリ別一覧 5.エージェント一覧 6.状態の定義 7.運用ルール 8.統合・整理の候補 9.次の一手。箇条書きは必ず番号リスト（ol）。黒丸「・」は使わない
- コネクタが無い場合はCSV/HTML/Markdownをファイルで渡す
- 作成後の編集にはSheets/Docsの編集用コネクタが必要

### Step 5 検証
1. 件数一致（CSV＝Notion＝Doc）
2. 状態の集計がDocの「現在の状況」と一致
3. ファイル名とNotion URLを報告

## 4. 月次更新ルール
1. 新規Skill/Agentは作成当日に1行追加
2. 月1回「要登録確認」を実際の一覧と突き合わせて「稼働中」へ
3. 統合候補は親を決めて子を廃止か統合
4. 更新の流れ：スプレッドシート → Notion → ドキュメント

## 5. 報告（短く）
1. 作ったもの3点
2. 件数（Skill/Agent、状態別）
3. 未確認事項
4. 次の一手を1つ

## 6. 禁止事項
1. 確認していない登録状況を「稼働中」と書かない
2. 無い情報を推測で埋めない
3. Word系出力で「・」の黒丸箇条書きを使わない
