# Node.js 徹底解説【初心者向け・公式docs準拠・図解つき】

> **対象**：プログラミング経験が浅い方、文系出身で未経験の方、JavaScriptは少し触った方
> **ゴール**：「Node.jsとは何か」を自分の言葉で説明でき、小さなプログラムを動かせる
> **根拠**：Node.js公式サイト（nodejs.org）の公式ドキュメント。確認日 2026-10-24
> **表記ルール**：
> - 🟦 **公式**：公式ドキュメントに書かれている事実
> - 🟨 **たとえ・見解**：理解のための筆者のたとえや助言（公式の記述ではありません）

---

## 0. 全体マップ

まず、この記事で学ぶ全体像です。迷ったらここに戻ってください。

```mermaid
mindmap
  root((Node.js))
    1 とは何か
      JavaScript実行環境
      V8エンジン
      ブラウザの外で動く
    2 なぜ速い
      1プロセス
      ノンブロッキングI/O
      イベントループ
    3 動かす
      node app.js
      HTTPサーバー
    4 部品
      CommonJS と ESM
      npm と package.json
    5 運用の入口
      LTSバージョン
      ブロックさせない
```

| 章 | 学ぶこと | 難易度 |
|---|---|---|
| 1 | Node.jsとは | ★☆☆☆☆ |
| 2 | なぜ大量の接続を扱えるか | ★★☆☆☆ |
| 3 | 実際に動かす | ★★☆☆☆ |
| 4 | ブロッキングとノンブロッキング | ★★★☆☆ |
| 5 | イベントループ | ★★★★☆ |
| 6 | ワーカープールと「ブロックさせない」 | ★★★★☆ |
| 7 | モジュール（CommonJSとESM） | ★★★☆☆ |
| 8 | npmとpackage.json | ★★☆☆☆ |
| 9 | バージョン選び（LTS） | ★☆☆☆☆ |

---

## 1. Node.jsとは？（What）

### 1-1. 公式の定義

🟦 **公式**
> Node.js is an open-source and cross-platform JavaScript runtime environment.
> （Node.jsは、オープンソースでクロスプラットフォームの JavaScript ランタイム環境です）

言葉を分解します。

| 用語 | 意味 |
|---|---|
| オープンソース | ソースコードが公開されていて、無料で使える |
| クロスプラットフォーム | Windows・macOS・Linuxなど、複数のOSで動く |
| ランタイム環境 | プログラムを「実行する」ための土台 |

🟦 **公式**：Node.jsを使うと、サーバー、Webアプリ、コマンドラインツール、スクリプトを作れます。

### 1-2. 「ブラウザの外」でJavaScriptが動く

🟦 **公式**
> Node.js runs the V8 JavaScript engine, the core of Google Chrome, outside of the browser.
> （Node.jsは、Google Chromeの中核であるV8 JavaScriptエンジンを、ブラウザの外で動かします）

```mermaid
flowchart LR
    subgraph B["これまで：ブラウザの中"]
        direction TB
        B1["JavaScriptのコード"] --> B2["V8エンジン<br/>（Chromeの中核）"]
        B2 --> B3["画面を動かす"]
    end
    subgraph N["Node.js：ブラウザの外"]
        direction TB
        N1["JavaScriptのコード"] --> N2["V8エンジン<br/>（同じエンジン）"]
        N2 --> N3["サーバー・ツール・スクリプト"]
    end
    B ~~~ N
```

🟨 **たとえ**：V8は「JavaScriptを読んで実行するエンジン」。同じエンジンを、ブラウザという車から取り出して、サーバーという別の車に積んだのがNode.js、とイメージするとわかりやすいです。

### 1-3. ここまでのまとめ

1. Node.jsは **JavaScriptを実行する環境**（言語そのものではない）
2. エンジンは **V8**（Chromeと同じ）
3. **ブラウザなしで**、サーバーやツールを作れる

---

## 2. なぜ大量の接続を扱えるのか（Why）

### 2-1. 公式が説明する3つの特徴

🟦 **公式**

1. **1つのプロセスで動き、リクエストごとにスレッドを作らない**
   > A Node.js app runs in a single process, without creating a new thread for every request.
2. **ノンブロッキングI/Oが基本**
   > blocking behavior is the exception rather than the norm in Node.js.
   （ブロックする動作は、Node.jsでは例外であり、普通ではありません）
3. **待っている間にCPUを無駄にしない**
   > instead of blocking the thread and wasting CPU cycles waiting, Node.js will resume the operations when the response comes back.
   （待つのではなく、応答が返ってきたときに処理を再開する）

その結果、公式はこう述べています。

🟦 **公式**
> Node.js to handle thousands of concurrent connections with a single server without introducing the burden of managing thread concurrency, which could be a significant source of bugs.
> （スレッドの並行処理を管理する負担を持ち込まずに、1台のサーバーで数千の同時接続を扱える。スレッドの管理は、バグの大きな原因になりうる）

### 2-2. 図で比べる：「リクエストごとにスレッド」vs「Node.js」

🟨 **たとえ話（レストラン）**

```mermaid
flowchart TB
    subgraph T["スレッド方式（お客さんごとに専属店員）"]
        direction LR
        C1["お客A"] --> W1["店員1<br/>料理を待つ"]
        C2["お客B"] --> W2["店員2<br/>料理を待つ"]
        C3["お客C"] --> W3["店員3<br/>料理を待つ"]
    end
    subgraph E["Node.js方式（1人の店員＋呼び出しベル）"]
        direction LR
        D1["お客A"] --> S["店員1人"]
        D2["お客B"] --> S
        D3["お客C"] --> S
        S --> K["厨房に注文を渡す<br/>待たずに次のお客へ"]
        K -->|"料理ができたらベル"| S
    end
    T ~~~ E
```

🟦 **公式**（About Node.js）：Node.jsは「非同期でイベント駆動のJavaScriptランタイム」で、スケーラブルなネットワークアプリを作るために設計されています。OSスレッドを使う一般的なモデルは、比較的非効率で使いにくい、と説明されています。また、**ロックがないので、デッドロックを心配する必要がない**とも書かれています。

### 2-3. 「並列」ではなく「待ち時間の有効活用」

🟨 **見解**：Node.jsが得意なのは「待ち時間が長い仕事（ネットワーク、データベース、ファイル）」です。計算が重い仕事は苦手です（6章で説明）。

---

## 3. 実際に動かしてみる（How）

### 3-1. スクリプトを実行する

🟦 **公式**（Run Node.js scripts from the command line）

```bash
node app.js
```

ファイル名を `node` に渡すだけです。他にも次の使い方があります。

| やりたいこと | コマンド | 補足（公式） |
|---|---|---|
| 文字列を評価する | `node -e "console.log(123)"` | Windowsのcmdではシングルクォートでなくダブルクォートを使う |
| 変更で自動再起動 | `node --watch app.js` | Node.js v16以降 |
| package.jsonのスクリプトを実行 | `node --run test` | `scripts` に定義が必要 |

### 3-2. 公式の「Hello World」Webサーバー

🟦 **公式**（Introduction to Node.js / About）：定番の例はWebサーバーです。

**CommonJS版**（`server.js` として保存し、`node server.js` で実行）

```js
const { createServer } = require('node:http');

const hostname = '127.0.0.1';
const port = 3000;

const server = createServer((req, res) => {
  res.statusCode = 200;
  res.setHeader('Content-Type', 'text/plain');
  res.end('Hello World');
});

server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});
```

**ESM版**（`server.mjs` として保存し、`node server.mjs` で実行）は、1行目だけ違います。

```js
import { createServer } from 'node:http';
```

ブラウザで `http://127.0.0.1:3000/` を開くと `Hello World` と表示されます。

### 3-3. コードの読み方

| 行 | 意味（🟨 見解の補足） |
|---|---|
| `createServer(...)` | Webサーバーを作る。中の関数は「リクエストが来たら呼ばれる」 |
| `req, res` | 受け取った要求（request）と、返す応答（response） |
| `res.statusCode = 200` | 「成功」を意味する番号 |
| `res.end('Hello World')` | 応答の本文を返して終了 |
| `server.listen(port, ...)` | 3000番ポートで待ち受け開始 |

```mermaid
sequenceDiagram
    participant Br as ブラウザ
    participant Sv as Node.jsサーバー
    Br->>Sv: ① http://127.0.0.1:3000/ にアクセス
    Note over Sv: 接続のたびにコールバックが呼ばれる
    Sv->>Sv: ② createServerの関数が実行される
    Sv-->>Br: ③ 200 と Hello World を返す
    Note over Sv: 仕事がないときは待機（sleep）
```

🟦 **公式**：接続のたびにコールバックが呼ばれ、**やることがなければNode.jsは待機（sleep）する**、と説明されています。

### 3-4. プログラムはいつ終わる？

🟦 **公式**：Node.jsは入力スクリプトを実行したあとイベントループに入り、**呼び出すべきコールバックがなくなったら終了**します。

🟨 **見解**：Webサーバーが止まらないのは、`listen` が「これから接続が来るかもしれない」状態を保つためです。

---

## 4. ブロッキングとノンブロッキング

### 4-1. 公式の定義

🟦 **公式**
> Blocking is when the execution of additional JavaScript in the Node.js process must wait until a non-JavaScript operation completes.
> （ブロッキングとは、JavaScript以外の操作が終わるまで、Node.jsプロセス内の他のJavaScriptの実行が待たされること）

| 種類 | 実行のされ方 | 名前の目印 |
|---|---|---|
| ブロッキング | 同期（synchronous） | `〜Sync` で終わるメソッドが多い |
| ノンブロッキング | 非同期（asynchronous） | コールバックを受け取る |

### 4-2. ファイル読み込みで比べる

🟦 **公式の例**

**ブロッキング（同期）**

```js
const fs = require('node:fs');

const data = fs.readFileSync('/file.md'); // ここで読み終わるまで止まる
console.log(data);
moreWork(); // console.log のあとに実行される
```

**ノンブロッキング（非同期）**

```js
const fs = require('node:fs');

fs.readFile('/file.md', (err, data) => {
  if (err) {
    throw err;
  }
  console.log(data);
});
moreWork(); // console.log より先に実行される
```

```mermaid
sequenceDiagram
    participant J as JavaScript
    participant K as OS（ファイル読み込み）
    rect rgb(255, 235, 230)
    Note over J,K: ブロッキング：readFileSync
    J->>K: ファイルを読んで
    K-->>J: 読み終わった（この間JSは待つ）
    J->>J: console.log → moreWork
    end
    rect rgb(230, 245, 235)
    Note over J,K: ノンブロッキング：readFile
    J->>K: ファイルを読んで（コールバック付き）
    J->>J: moreWork をすぐ実行
    K-->>J: 読み終わったら通知
    J->>J: コールバックで console.log
    end
```

🟦 **公式**：`moreWork()` を、ファイルの読み込み完了を待たずに実行できることが、**高いスループット（処理量）を実現する重要な設計判断**だと説明されています。

### 4-3. 数字で理解する（公式の例）

🟦 **公式**：1リクエストに50msかかり、そのうち45msがデータベースI/Oで非同期にできる場合、ノンブロッキングを選ぶと、**リクエストあたり45msを他のリクエストの処理に回せます**。

```mermaid
flowchart LR
    A["JavaScriptの処理<br/>5ms"] --> B["データベースの待ち<br/>45ms"]
    B --> C["応答を返す<br/>合計50ms"]
    B -.->|"非同期なら、この45msの間に"| D["他のリクエストの<br/>JavaScriptを処理できる"]
```

### 4-4. 混ぜると危険（公式の注意）

```js
const fs = require('node:fs');

fs.readFile('/file.md', (err, data) => {
  if (err) {
    throw err;
  }
  console.log(data);
});
fs.unlinkSync('/file.md'); // 削除が先に実行されるおそれ
```

🟦 **公式**：`fs.unlinkSync()` が `fs.readFile()` より**先に実行**され、読む前にファイルが消えるおそれがあります。

**正しい書き方**（非同期の中で、次の非同期を呼ぶ）

```js
const fs = require('node:fs');

fs.readFile('/file.md', (readFileErr, data) => {
  if (readFileErr) {
    throw readFileErr;
  }
  console.log(data);

  fs.unlink('/file.md', unlinkErr => {
    if (unlinkErr) {
      throw unlinkErr;
    }
  });
});
```

🟦 **公式**：コールバックの中で呼ぶことで、**正しい順序が保証**されます。

---

## 5. イベントループ（核心）

### 5-1. 公式の説明

🟦 **公式**
> The event loop is what allows Node.js to perform non-blocking I/O operations — despite the fact that a single JavaScript thread is used by default — by offloading operations to the system kernel whenever possible.
> （イベントループのおかげで、既定ではJavaScriptのスレッドが1つでも、可能な限り処理をOSカーネルに任せることで、ノンブロッキングI/Oができる）

OSが「終わったよ」と知らせたら、対応するコールバックが**pollキュー**に追加されて実行されます。

### 5-2. 6つのフェーズ

🟦 **公式の図の順序**

```mermaid
flowchart LR
    T["① timers<br/>setTimeout / setInterval"] --> P1["② pending callbacks<br/>一部のシステムコールバック"]
    P1 --> I["③ idle, prepare<br/>内部でのみ使用"]
    I --> PO["④ poll<br/>新しいI/Oの取得と実行"]
    PO --> CH["⑤ check<br/>setImmediate"]
    CH --> CL["⑥ close callbacks<br/>closeイベントなど"]
    CL --> T
```

| フェーズ | やること（公式） |
|---|---|
| timers | `setTimeout()` と `setInterval()` で予約したコールバックを実行 |
| pending callbacks | 次の周回に延期された一部のシステムコールバック（例：一部のTCPエラー） |
| idle, prepare | 内部でのみ使用 |
| poll | 新しいI/Oイベントを取得し、I/O関連のコールバックを実行。**適切なときはここで待機（ブロック）する** |
| check | `setImmediate()` のコールバックを実行 |
| close callbacks | `socket.on('close', ...)` などの終了処理 |

> ⚠️ **バージョンの注意（公式）**：libuv 1.45.0（Node.js 20）以降は、**各周回でtimersがpollフェーズの後に実行**されます。それ以前はpollの前でした。図は公式の説明順です。

### 5-3. pollフェーズの動き

```mermaid
flowchart TD
    A["pollフェーズに入る"] --> B{"pollキューは空？"}
    B -->|"空でない"| C["コールバックを順に実行<br/>（空になるか上限まで）"]
    B -->|"空"| D{"setImmediateの予約あり？"}
    D -->|"あり"| E["pollを終えて checkへ"]
    D -->|"なし"| F["コールバックが来るまで待つ<br/>（来たらすぐ実行）"]
    C --> G["timersの時間が来ていれば<br/>timersへ戻る"]
    F --> G
```

### 5-4. `setTimeout` と `setImmediate` の違い

🟦 **公式**

| 関数 | 実行のタイミング |
|---|---|
| `setImmediate()` | 現在のpollフェーズが終わったあと（checkフェーズ） |
| `setTimeout()` | 指定した最小時間（ms）が経過したあと（timersフェーズ） |

🟦 **公式**：タイマーの時間は「**この時間を過ぎたら実行されうる**」しきい値であり、**正確な実行時刻ではありません**。

**メインモジュールからの呼び出しでは、順序は決まりません。**

```js
// timeout_vs_immediate.js
setTimeout(() => {
  console.log('timeout');
}, 0);

setImmediate(() => {
  console.log('immediate');
});
// 出力は "timeout, immediate" か "immediate, timeout" のどちらにもなりうる
```

**I/Oコールバックの中では、`immediate` が必ず先**です。

```js
const fs = require('node:fs');

fs.readFile(__filename, () => {
  setTimeout(() => console.log('timeout'), 0);
  setImmediate(() => console.log('immediate'));
});
// 出力：immediate, timeout
```

🟦 **公式**：公式は「**すべての場合で `setImmediate()` を使うことを推奨**する。理解しやすいから」と述べています。

### 5-5. `process.nextTick()` は特別

🟦 **公式**
- 技術的には**イベントループの一部ではありません**
- 現在の操作が終わったあと、**どのフェーズにいても**、`nextTickQueue` が処理されます
- `process.nextTick()` で予約したコールバックは、**イベントループが次へ進む前にすべて実行**されます

⚠️ **公式の警告**：`process.nextTick()` を再帰的に呼ぶと、イベントループが **poll に到達できず、I/Oが「飢餓状態（starve）」になります**。

```js
let bar = null;

function someAsyncApiCall(callback) {
  process.nextTick(callback);
}

someAsyncApiCall(() => {
  console.log('bar', bar); // 1
});

bar = 1;
```

🟦 **公式**：この例では、呼び出し元が `bar = 1` を設定し終えてから、コールバックを実行できます。

🟨 **見解**：初心者はまず「**`nextTick` は最優先の割り込み。使いすぎ注意**」と覚えれば十分です。

---

## 6. ワーカープールと「ブロックさせない」

### 6-1. なぜブロックさせてはいけないか

🟦 **公式**（Don't Block the Event Loop）
> While a thread is blocked working on behalf of one client, it cannot handle requests from any other clients.
> （あるクライアントのためにスレッドがブロックされている間は、他のクライアントのリクエストを処理できない）

ブロックの害は2つあります。

1. **性能**：スループット（秒あたりの処理数）が落ちる
2. **セキュリティ**：悪意あるクライアントが、スレッドをブロックさせる入力を送ると、**サービス拒否（DoS）攻撃**になる

🟦 **公式の目安**：**クライアントごとの仕事が小さいときに、Node.jsは速い。**

### 6-2. 2種類のスレッド

```mermaid
flowchart LR
    subgraph EL["イベントループ（スレッド1つ）"]
        E1["JavaScriptのコールバック"]
        E2["Promiseの処理 / await の続き"]
        E3["ノンブロッキングのネットワークI/O"]
    end
    subgraph WP["ワーカープール（libuv・既定4スレッド）"]
        W1["ファイル操作（fs）"]
        W2["暗号処理（一部のcrypto）"]
        W3["圧縮（zlib）・dns.lookup"]
    end
    EL -->|"重い仕事を渡す"| WP
    WP -->|"終わったら通知"| EL
```

| | イベントループ | ワーカープール（libuv） |
|---|---|---|
| 担当 | JSのコールバック、Promise、`await`の続き、ネットワークI/O | 重い仕事（一部のI/OとCPU処理） |
| スレッド数 | 1 | k（libuvの既定は4） |

🟦 **公式**：ワーカープールで動くもの

- DNS：`dns.lookup()`、`dns.lookupService()`
- ファイルシステム：`fs` のAPI（`fs.FSWatcher()` と明示的に同期のものを除く）
- 暗号：`crypto.pbkdf2()`、`crypto.scrypt()`、`crypto.randomBytes()` など
- 圧縮：zlibのAPI（明示的に同期のものを除く）

🟦 **公式**：**同期API**（`crypto.pbkdf2Sync`、`zlib.inflateSync`、`child_process.execSync`、`fs`の同期呼び出しなど）は**イベントループ上で動く**ので、サーバーでは避けるべきです。

### 6-3. 公式が挙げるブロックの原因

| 原因 | 内容（公式） | 対策 |
|---|---|---|
| ReDoS | `(a+)*` のような入れ子の量指定子は、入力次第で極端に遅くなる | 単純な一致なら `indexOf`、入力長を制限 |
| 巨大なJSON | `JSON.parse` / `JSON.stringify` は入力サイズに比例。50MBの文字列で約1.3秒かかった例 | クライアントのJSONサイズを制限、またはストリーミング解析 |
| CPUを使う計算 | 長いループは他のクライアントを待たせる | 分割して `setImmediate` で譲る／別のプールに任せる |

🟦 **公式**：CPU重視の処理を分割する例

```js
function asyncAvg(n, avgCB) {
  let sum = 0;
  function help(i, cb) {
    sum += i;
    if (i == n) {
      cb(sum);
      return;
    }
    setImmediate(help.bind(null, i + 1, cb));
  }
  help(1, (sum) => avgCB(sum / n));
}
```

🟦 **公式**：サーバーが複雑な計算に大きく依存するなら、**Node.jsが適切か**を考えるべき。Node.jsは**I/Oが中心の仕事**が得意、と述べられています。

### 6-4. 複数コアを使うには

🟦 **公式**（About）：スレッドがなくても、`child_process.fork()` で子プロセスを作ると複数コアを使えます。`cluster` モジュールを使うと、プロセス間でソケットを共有して負荷分散できます。

---

## 7. モジュール：CommonJS と ESM

### 7-1. 2つのモジュール方式

🟦 **公式**：Node.jsには2つのモジュールシステムがあります。

| | CommonJS | ESM（ECMAScript modules） |
|---|---|---|
| 読み込み | `require()` | `import` |
| 拡張子の目印 | `.cjs` | `.mjs` |
| package.json | `"type": "commonjs"` | `"type": "module"` |

### 7-2. どちらとして実行されるか

🟦 **公式**：目印があればそれが優先されます。目印がない場合は、**ソースを調べてES moduleの構文が見つかればESM、なければCommonJS**として実行されます。

```mermaid
flowchart TD
    A["ファイルを実行"] --> B{"拡張子は？"}
    B -->|".mjs"| E["ESM"]
    B -->|".cjs"| C["CommonJS"]
    B -->|".js"| D{"package.jsonのtype"}
    D -->|"module"| E
    D -->|"commonjs"| C
    D -->|"指定なし"| F{"ES module構文がある？"}
    F -->|"ある"| E
    F -->|"ない"| C
```

> 🟨 図の `.js` の分岐は、公式が示す3つの目印（`.mjs` / `.cjs` / `package.json` の `type`）と、目印なしの場合の判定を整理したものです。

### 7-3. ESMの基本

🟦 **公式の例**

```js
// addTwo.mjs
function addTwo(num) {
  return num + 2;
}

export { addTwo };
```

```js
// app.mjs
import { addTwo } from './addTwo.mjs';

// Prints: 6
console.log(addTwo(4));
```

| ルール | 内容（公式） |
|---|---|
| 拡張子は必須 | `'./startup/index.js'` のように書く |
| 組み込みモジュール | `node:` を付ける（例：`import fs from 'node:fs/promises';`） |
| JSONの読み込み | `import packageConfig from './package.json' with { type: 'json' };` |
| 動的import | `import()` はCommonJSでもESMでも使える |

### 7-4. ESMで使えなくなるもの

🟦 **公式**

| CommonJSで使えたもの | ESMでの代わり |
|---|---|
| `require`, `exports`, `module.exports` | `import` / `export`（必要なら `module.createRequire()`） |
| `__filename`, `__dirname` | `import.meta.filename`, `import.meta.dirname` |
| `require.main` | `import.meta.main` |
| `require.resolve` | `import.meta.resolve()` |

🟨 **見解**：初心者がよくつまずくのは「`require is not defined`」のエラーです。ファイルがESMとして扱われているのに `require` を書いていないか、上の判定図で確認しましょう。

---

## 8. npmとpackage.json

### 8-1. npmとは

🟦 **公式**
> npm is the standard package manager for Node.js.
> （npmはNode.jsの標準のパッケージマネージャー）

もともとは依存パッケージの取得・管理のためのツールでしたが、いまはフロントエンドでも使われています。YarnやpnpmもCLIの代替として挙げられています。

### 8-2. 流れの図

```mermaid
flowchart LR
    R["npmレジストリ<br/>（パッケージの置き場）"] -->|"npm install"| NM["node_modules<br/>（依存の保存先）"]
    PJ["package.json<br/>（依存と scripts の一覧）"] -->|"何を入れるか"| NM
    PJ -->|"npm run 名前"| S["scripts のコマンドを実行"]
    NM --> APP["あなたのアプリ"]
```

### 8-3. よく使うコマンド

🟦 **公式**

| やりたいこと | コマンド |
|---|---|
| package.jsonの内容をまとめて入れる | `npm install` |
| 1つ入れる | `npm install <package-name>` |
| 開発用として入れる | `npm install <package-name> -D`（`--save-dev`） |
| 保存せずに入れる | `npm install <package-name> --no-save` |
| 更新する | `npm update` ／ `npm update <package-name>` |
| バージョン指定 | `npm install <package-name>@<version>` |
| タスク実行 | `npm run <task-name>` |

🟦 **公式**：`npm install <package-name>` は、npm 5以降、自動で `package.json` の **dependencies** に追加されます（それ以前は `--save` が必要でした）。

### 8-4. dependencies と devDependencies

🟦 **公式**

| 項目 | 中身 |
|---|---|
| `dependencies` | 本番でアプリと一緒に使うもの |
| `devDependencies` | 開発用ツール（例：テストライブラリ） |
| `optionalDependencies` | 入れるのに失敗しても、インストール全体は失敗しない。ただし、無い場合の対処はプログラム側の責任 |

### 8-5. scripts：長いコマンドに名前を付ける

🟦 **公式の例**

```json
{
  "scripts": {
    "start-dev": "node lib/server-development",
    "start": "node lib/server-production"
  }
}
```

```bash
npm run start-dev
```

🟦 **公式の理由**：長いコマンドは「忘れやすく、打ち間違えやすい」ので、短い名前で実行できるようにします。

### 8-6. semver（バージョンの付け方）

🟦 **公式**：npmは**セマンティックバージョニング（semver）**に従います。

---

## 9. バージョン選び：LTSとは

### 9-1. 公式のリリース区分

| 区分 | 意味（公式） |
|---|---|
| Current | メジャーバージョンが**6か月間**この状態。ライブラリ作者が対応する時間 |
| Active LTS | 偶数番号のリリースが移る。**一般利用の準備ができた状態** |
| Maintenance LTS | 本番で使ってよい区分（定義の詳細は公式の別ページ） |
| EOL | サポート終了 |

🟦 **公式**：**本番アプリケーションは、Active LTS または Maintenance LTS のみを使うべき**。LTSは一般に、重大なバグ修正が**合計30か月**保証されます。

```mermaid
flowchart LR
    A["Current<br/>6か月"] --> B["Active LTS<br/>一般利用OK"]
    B --> C["Maintenance LTS<br/>本番はここまで"]
    C --> D["EOL<br/>サポート終了"]
```

### 9-2. いまのバージョン（確認日 2026-10-24）

🟦 **公式**（Previous Releases）

| Node.js | コードネーム | 初回リリース | 状態 |
|---|---|---|---|
| v26 | - | 2026-05-05 | Current |
| v24 | Krypton | 2025-05-06 | LTS |
| v22 | Jod | 2024-04-24 | LTS |

公式サイトの表示では、最新LTSは **v24.22.1**、最新リリースは **v26.12.1** です。

🟦 **公式**：Node.js 26までは、奇数番号は6か月でサポート終了、偶数番号がActive LTSへ移ります。**Node.js 27からは年1回のリリースになり、すべてのメジャーバージョンがLTSになる予定**です。

🟨 **助言**：学習や仕事で使うなら、**LTSを選ぶ**のが基本です。バージョンは変わるので、必ず[公式のリリース表](https://nodejs.org/en/about/previous-releases)で最新を確認してください。

---

## 10. 初心者がつまずく8つのポイント

🟨 **見解**（公式の事実を土台にした、筆者の経験則です）

| # | つまずき | 原因と対処 |
|---|---|---|
| 1 | 「Node.jsはJavaScriptの別言語？」 | 言語ではなく**実行環境**。言語はJavaScript（1章） |
| 2 | 出力の順番が思った通りにならない | 非同期は**完了を待たずに次へ進む**（4章） |
| 3 | `setTimeout(…, 0)` と `setImmediate` の順序が不安定 | メインモジュールでは**不定**。I/Oの中なら `immediate` が先（5章） |
| 4 | サーバーが突然遅くなる | 重い同期処理が**他の全員を待たせている**（6章） |
| 5 | `require is not defined` | ESMとして実行されている。判定図を確認（7章） |
| 6 | `__dirname is not defined` | ESMでは `import.meta.dirname` を使う（7章） |
| 7 | `node_modules` をどうするか分からない | `package.json` があれば `npm install` で再現できる（8章） |
| 8 | どのバージョンを入れるか迷う | **LTS**を選ぶ（9章） |

---

## 11. ミニ演習（答えは下）

**Q1.** Node.jsは「言語」か「実行環境」か。使われているJavaScriptエンジンは何か。

**Q2.** 次のコードで、`A` `B` `C` の出力順は？ 理由も答えてください。

```js
const fs = require('node:fs');
console.log('A');
fs.readFile(__filename, () => console.log('B'));
console.log('C');
```

**Q3.** `fs.readFileSync` と `fs.readFile` の違いを、「ブロッキング」という言葉を使って説明してください。

**Q4.** `node:fs` の `node:` は何のため？ ESMでJSONを読み込むときに必要なものは？

**Q5.** 本番で使うバージョンは、どの区分から選ぶべき？

<details>
<summary>答えを見る</summary>

**A1.** 実行環境（ランタイム）。V8エンジン。

**A2.** `A` → `C` → `B`。`readFile` はノンブロッキングなので、読み込み完了を待たずに次の行へ進み、完了後にコールバックが実行されるため。（4章）

**A3.** `readFileSync` は読み終わるまで他のJavaScriptの実行を**ブロック**（同期）する。`readFile` は**ノンブロッキング**（非同期）で、読み込み中も他の処理を進められる。（4章）

**A4.** 組み込みモジュールであることを示す接頭辞（公式のESMの例で使用）。JSONは `with { type: 'json' }`（import attributes）が必要。（7章）

**A5.** Active LTS または Maintenance LTS。（9章）

</details>

---

## 12. 理解度チェックリスト

- [ ] Node.jsを「JavaScript実行環境」と説明できる
- [ ] V8エンジンがブラウザの外で動くことを説明できる
- [ ] 「リクエストごとにスレッドを作らない」意味を言える
- [ ] ブロッキングとノンブロッキングの違いを、コードで示せる
- [ ] イベントループの6フェーズの順番を言える
- [ ] `setTimeout` / `setImmediate` / `process.nextTick` の違いを説明できる
- [ ] 重い同期処理がなぜ危険か（性能とセキュリティ）を言える
- [ ] CommonJSとESMの判定ルールを説明できる
- [ ] `package.json` の `dependencies` と `devDependencies` の違いを言える
- [ ] 本番ではLTSを使う理由を言える

---

## 13. 次の学習ステップ

1. 公式の「Learn」で手を動かす（[nodejs.org/learn](https://nodejs.org/learn)）
2. `node --watch` で小さなHTTPサーバーを書き換えながら動かす
3. `fs` の `Promise` 版（`node:fs/promises`）で、async/await を試す
4. npmで1つ依存パッケージを入れて、`package.json` の変化を観察する

---

## 出典（公式ドキュメント／確認日 2026-10-24）

- [Introduction to Node.js](https://nodejs.org/learn/getting-started/introduction-to-nodejs)
- [About Node.js](https://nodejs.org/en/about)
- [Run Node.js scripts from the command line](https://nodejs.org/learn/command-line/run-nodejs-scripts-from-the-command-line)
- [Overview of Blocking vs Non-Blocking](https://nodejs.org/learn/asynchronous-work/overview-of-blocking-vs-non-blocking)
- [The Node.js Event Loop](https://nodejs.org/learn/asynchronous-work/event-loop-timers-and-nexttick)
- [Don't Block the Event Loop (or the Worker Pool)](https://nodejs.org/learn/asynchronous-work/dont-block-the-event-loop)
- [Modules: ECMAScript modules](https://nodejs.org/api/esm.html)
- [An introduction to the npm package manager](https://nodejs.org/learn/getting-started/an-introduction-to-the-npm-package-manager)
- [Node.js Releases](https://nodejs.org/en/about/previous-releases)

> **注意**：公式ドキュメントは更新されます。バージョン番号・日付・既定値は、必ず最新の公式ページで再確認してください。英語の引用は公式の記述を、日本語はその意訳です。🟨 の記述は公式の記述ではありません。
