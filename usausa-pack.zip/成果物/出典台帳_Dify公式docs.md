# 出典台帳（確認日 2026-10-24）
| 項目 | 事実 | URL |
|---|---|---|
| 概念 | 主要アプリタイプはWorkflow/Chatflow。レガシー3種あり。変数4種。DSL | docs.dify.ai/ja/use-dify/getting-started/key-concepts |
| RAG | ナレッジ作成3種。検索検証・メタデータ | docs.dify.ai/ja/use-dify/knowledge/readme |
| 索引・検索 | 高品質/経済的、TopK既定3、閾値0.5、Rerank既定オフ | docs.dify.ai/en/use-dify/knowledge/create-knowledge/setting-indexing-methods |
| LLMノード | 7機能 | docs.dify.ai/en/self-host/use-dify/nodes/llm |
| ナレッジ検索ノード | クエリ・メタデータ絞り込み・出力result | docs.dify.ai/en/self-host/use-dify/nodes/knowledge-retrieval |
| 公開 | Web/API/埋め込み/MCP | docs.dify.ai/en/self-host/use-dify/publish/README |
| ログ | 会話全文・保持期間の環境変数 | docs.dify.ai/en/self-host/use-dify/monitor/logs |
| セルフホスト | 2コア/4GiB、Compose 2.24.0+、/install | docs.dify.ai/en/self-host/deploy/quick-start/docker-compose |
| ツール | Marketplace・判定ルーティング | docs.dify.ai/en/use-dify/tutorials/workflow-101/lesson-07 |
| 未確認 | ノード各個の詳細（Code/HTTP/Iteration等の仕様）、チャンク設定詳細、Marketplace公開手順 | 公式で再確認 |
